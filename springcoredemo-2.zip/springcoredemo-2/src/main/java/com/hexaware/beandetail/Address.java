package com.hexaware.beandetail;

public class Address {
  public void print()
  {
	  System.out.println("it has address");
  }
}
