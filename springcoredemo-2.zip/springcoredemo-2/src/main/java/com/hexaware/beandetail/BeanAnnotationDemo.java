package com.hexaware.beandetail;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BeanAnnotationDemo {
	public static void main(String args[])
	{
		
		try(AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class))
		{
	        Student student1 = context.getBean(Student.class);
	        student1.print1();
	        String[] beannames=context.getBeanDefinitionNames();
	        for(String dtr:beannames)
	        {
	        	System.out.println(dtr);
	        }
		}
     }
}