package com.hexaware.beandetail;

public class Student {
  private Address address;
  public Student(Address address) {
		super();
		this.address = address;
	}
    public void init()
    {
      System.out.println("Initialization logic");
    }
    public void destroy()
    {
    	System.out.println("Destruction logic");
    }
	public void print1()
	{
		this.address.print();
		System.out.println("Print from student");
	}

  
}
