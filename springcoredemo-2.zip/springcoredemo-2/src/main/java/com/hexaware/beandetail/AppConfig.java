package com.hexaware.beandetail;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	@Bean(name="addressBean")
	public Address address()
	{
		return new Address();
	}
	@Bean(initMethod="init",destroyMethod="destroy",name={"studentBean","BeanofStudent"})
	public Student student()
	{
		 return new Student(address());
	}

}
