package com.hexaware.circular;

import org.springframework.beans.factory.annotation.Autowired;

public class DependencyB {
	private DependancyA da;
    
	@Autowired
	public void setDa(DependancyA da) {
		this.da = da;
	}
	/*
     public DependencyB(DependancyA da) {
		super();
		this.da = da;
	}
     */
     
     
}
