package com.hexaware.circular;

import org.springframework.beans.factory.annotation.Autowired;

public class DependancyA {
    private DependencyB db;
    
    @Autowired
    public void setDb(DependencyB db) {
		this.db = db;
	}
    /*
    public DependancyA(DependencyB db)
    {
    	super();
    	this.db=db;
    }*/


	
    
}
