package com.hexaware.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("message")
public class MessageSender {
	     //@Autowired
	     //@Qualifier("sms")
         private MessageService messageservice1;
	     //@Autowired
	     //@Qualifier("email")
         private MessageService messageservice2;
         
        @Autowired// work internally
         
        public MessageSender(@Qualifier("sms")MessageService messageservice1,  @Qualifier("email")MessageService messageservice2)
         {
        	 this.messageservice1=messageservice1;
        	 System.out.println("Constructor injected bean for sms"+ this.messageservice1);
        	 this.messageservice2=messageservice2;
        	 System.out.println("Constructor injected bean for email"+ this.messageservice2);
         }
         
         /*public MessageSender()
         {
        	 super();
         }*/
         /*
         @Autowired
         @Qualifier("sms")
         public void setMessageservice1( MessageService messageservice1) {
 			this.messageservice1 = messageservice1;
 			System.out.println("Constructor injected bean for sms"+ this.messageservice1);
 		}
         @Autowired
         @Qualifier("email")
 		public void setMessageservice2( MessageService messageservice2) {
 			this.messageservice2 = messageservice2;
 			System.out.println("Constructor injected bean for email"+ this.messageservice2);
 		}
 		*/
 		
         public void displaymessage(String message,String type)
         {
        	 if(type.equals("sms"))
        		 this.messageservice1.sendmessage(message);
        	 else
        		 this.messageservice2.sendmessage(message);
         }
         
         
		
		
}
