package com.hexaware.springcoredemo;

import org.springframework.stereotype.Component;

@Component("email")
public class Emailservice implements MessageService{
	public void sendmessage(String message)
	{
		System.out.println(message+" email");
	}
	public String toString()
    {
    	return "Email";
    }
}
