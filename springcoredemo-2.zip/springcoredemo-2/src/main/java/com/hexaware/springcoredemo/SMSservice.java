package com.hexaware.springcoredemo;

import org.springframework.stereotype.Component;

@Component("sms")
public class SMSservice implements MessageService{
	public void sendmessage(String message)
	{
		System.out.println(message+" sms");
	}
    public String toString()
    {
    	return "Sms";
    }
}
