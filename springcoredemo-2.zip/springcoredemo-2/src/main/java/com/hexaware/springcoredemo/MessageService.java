package com.hexaware.springcoredemo;

public interface MessageService {
     public void sendmessage(String message);
}
