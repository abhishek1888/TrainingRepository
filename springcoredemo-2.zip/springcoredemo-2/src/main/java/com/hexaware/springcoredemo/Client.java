package com.hexaware.springcoredemo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.*;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
        //MessageSender messagesender= (MessageSender)context.getBean("message");
        // Alternate way
        //MessageSender messagesender= context.getBean(MessageSender.class);
       // messagesender.displaymessage("Send this message through","email");
        //messagesender.displaymessage("Send this message through","sms");
        MessageService message1= context.getBean(SMSservice.class);
        MessageService message2= context.getBean(Emailservice.class);
       // MessageSender messagesender= new MessageSender(message1,message2);
        MessageSender messagesender= context.getBean(MessageSender.class);
        messagesender.displaymessage("hey through","sms");
	}

}
