package com.hexaware.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;

// constructor based dependency
// ypu cannot assign final dependecies using setter injection and field injection, but can do with constructor injection
class Dependencya{}
class Dependencyb{}
class Dependencyc{}
public class Demo {
	
		//final Dependencya da;
	    //final Dependencyb db;
	    //final Dependencyc dc;
	 @Autowired 
	 Dependencya da;
	 @Autowired 
	 Dependencyb db;
	 @Autowired 
	 Dependencyc dc;
    /* public Demo(Dependencya da, Dependencyb db, Dependencyc dc) {
		super();
		this.da = da;
		this.db = db;
		this.dc = dc;
	}
    */
    /* public void setDepA(Dependencya a)
     {
    	// this.da=a;
     }
     */
		
        
        
}
