package com.hexaware.demo1;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository("sql")
public class MySqlDataSource implements Datasource{
	public void returnConnection()
    {
    	System.out.println("Connected to MySql");
    }
}
