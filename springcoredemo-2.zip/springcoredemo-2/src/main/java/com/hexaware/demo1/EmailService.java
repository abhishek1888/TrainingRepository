package com.hexaware.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("emailservice")
public class EmailService {
	private Datasource ds;
	
	@Autowired
	public EmailService(Datasource ds)
	{
		this.ds=ds;
	}
    public void sendemail()
    {
    	this.ds.returnConnection();
    }
}
