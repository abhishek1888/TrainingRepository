package com.hexaware.demo1;

public interface Datasource {
       public void returnConnection();
}
