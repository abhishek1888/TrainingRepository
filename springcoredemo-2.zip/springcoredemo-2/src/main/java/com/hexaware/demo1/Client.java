package com.hexaware.demo1;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
             ApplicationContext context= new AnnotationConfigApplicationContext(AppConfig.class);
             // ApplicationContext context= new AnnotationConfigApplicationContext("com.hexaware.demo1");
             Scanner sc=new Scanner(System.in);
             
             EmailService service= (EmailService)context.getBean("emailservice");
             service.sendemail();
	}

}
