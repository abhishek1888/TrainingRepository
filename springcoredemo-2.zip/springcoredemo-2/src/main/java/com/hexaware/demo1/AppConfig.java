package com.hexaware.demo1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration("config")
@ComponentScan("com.hexaware.demo1")
public class AppConfig {

}
