package com.hexaware.dao;

import com.hexaware.Mainmod.Mainmod;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.exceptions.AccountNumberInvalidException;
import com.hexaware.exceptions.InsufficientFundsException;
import com.hexaware.exceptions.NegativeAmountException;
import java.util.logging.*;

public class ServiceProviderImpl {
    private Bank mybank;
     
    public ServiceProviderImpl(Bank mybank)
    {
    	this.mybank=mybank;
    }
    public BankAccount searchAccount(long accountNumber) throws AccountNumberInvalidException
    {
    	 BankAccount myAccount=null;
    	 for(BankAccount account: mybank.getAccountList())
    	 {
    		 if(account.getAccountNumber()==accountNumber)
    		 {
    			 myAccount=account;
    			 break;
    		 }
    	 }
    	 if(myAccount==null)
    		 throw new AccountNumberInvalidException("This account is not valid");
    	 return myAccount;
    }
    public double checkbalance(long accountNumber) throws AccountNumberInvalidException
    {
    	BankAccount myAccount=null;
    	myAccount=searchAccount(accountNumber);
    	return myAccount.getBalance();
    		
    }
    public boolean deposit(long accountNumber, double amount) throws AccountNumberInvalidException, NegativeAmountException
    {
    	BankAccount myAccount=null;
    	boolean depositstatus=false;
    	myAccount=searchAccount(accountNumber);
    	if(amount<0)
    		throw new NegativeAmountException("The amount is negative");
    	myAccount.setBalance(myAccount.getBalance()+amount);
    	depositstatus=true;
    	return depositstatus;
    }
    public boolean withdraw(long accountNumber, double amount) throws AccountNumberInvalidException,InsufficientFundsException, NegativeAmountException
    {
    	BankAccount myAccount=null;
    	boolean withdrawstatus=false;
    	myAccount=searchAccount(accountNumber);
        if(amount>myAccount.getBalance())
    		throw new InsufficientFundsException("The funds are not sufficient");
    	if(amount<0)
    		throw new NegativeAmountException("The amount is negative");
    	myAccount.setBalance(myAccount.getBalance()-amount);
    	withdrawstatus=true;
    	return withdrawstatus;
    }
    public boolean removeAccount(long accountNumber) throws AccountNumberInvalidException
    {
    	BankAccount myAccount=null;
    	boolean removeAccountstatus=false;
    	myAccount=searchAccount(accountNumber);
    	mybank.getAccountList().remove(myAccount);
    	removeAccountstatus=true;
    	return removeAccountstatus;
    }
    public boolean createAccount(BankAccount newAcc)
    {
    	boolean createAccountstatus=false;
    	mybank.getAccountList().add(newAcc);
    	createAccountstatus=true;
    	return createAccountstatus;
    }
}
