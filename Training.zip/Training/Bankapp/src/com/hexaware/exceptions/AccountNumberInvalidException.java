package com.hexaware.exceptions;

public class AccountNumberInvalidException extends Exception {
     public AccountNumberInvalidException(String message) {
    	 super(message);
     }
}
