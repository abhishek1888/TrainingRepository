package com.hexaware.Mainmod;

import java.util.ArrayList;
import java.util.logging.*;


import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.exceptions.AccountNumberInvalidException;
import com.hexaware.exceptions.InsufficientFundsException;
import com.hexaware.exceptions.NegativeAmountException;
public class Mainmod {
    //private final static Logger lOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	private static final Logger LOGGER = Logger.getLogger(Mainmod.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         ArrayList<BankAccount> BankaccontList = new ArrayList<>();
         BankaccontList.add(new BankAccount("Abhishek","Current",678900.00));
         BankaccontList.add(new BankAccount("Arun","Savings",459000.00));
         BankaccontList.add(new BankAccount("Bhuvan","Current",1001000.00));
         BankaccontList.add(new BankAccount("Chirag","Savings",537000.00));
         
         Bank bankObj= new Bank("SBI",BankaccontList);
        
         ServiceProviderImpl service = new ServiceProviderImpl(bankObj);
         LOGGER.info("Starting the MainMod program.");
         try
         {
             System.out.println(service.searchAccount(1110));
             LOGGER.info("The Account to be searched 1110 is present");
         }
         catch(AccountNumberInvalidException e)
         {
        	 LOGGER.warning("Account number is invalid");
        	  e.printStackTrace();
         }
         try
         {
        	 LOGGER.info("To check Balance for account number 1111");
        	 System.out.println("The balance for account is: " +service.checkbalance(1111));
         }
         catch(AccountNumberInvalidException e)
         {
        	 LOGGER.warning("Account number is invalid");
        	  e.printStackTrace();
         }
         
         try
         {
        	 LOGGER.info("depositing 1000.00 in accountnumber 1112");
        	 System.out.println("the status is :"+service.deposit(1112,1000.00));
        	 System.out.println(bankObj);
         }
         catch(AccountNumberInvalidException e1)
         {
        	 LOGGER.warning("Account number is invalid");
        	 e1.printStackTrace();
         }
         catch(NegativeAmountException e2)
         {
        	 LOGGER.warning("The amount cannot be negative");
        	 e2.printStackTrace();
         }
         
         try
         {
        	 LOGGER.info("Withsraw amount 1113 from account 1113");
        	 System.out.println("The status is: " +service.withdraw(1113,1000.00));
        	 System.out.println(bankObj);
         }
         catch(AccountNumberInvalidException e1)
         {
        	 LOGGER.warning("Account number is invalid");
        	 e1.printStackTrace();
         }
         catch(NegativeAmountException e2)
         {
        	 LOGGER.warning("Account number is invalid");
        	 e2.printStackTrace();
         }
         catch(InsufficientFundsException e3)
         {
        	 LOGGER.warning("The amount in the account is not enough");
        	 e3.printStackTrace();
         }
         LOGGER.info("hey");
         try
         {
        	 LOGGER.info("The Account removed is 1110");
        	 System.out.println("The account is removed successfully " +service.removeAccount(1110));
        	 System.out.println(bankObj);
         }
         catch(AccountNumberInvalidException e1)
         {
        	 LOGGER.warning("Account number is invalid");
        	 e1.printStackTrace();
         }
         LOGGER.info("A new Account is created");
         System.out.println("The account is created successfully " +service.createAccount(new BankAccount("Suresh","Current",984500.89)));
         System.out.println(bankObj);
         
         LOGGER.info("Program end");
         
	}

}
