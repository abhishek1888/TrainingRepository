package com.SerachEngine;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringSearchEngine {
	private String Giventext;

    public StringSearchEngine(String Giventext) {
        this.Giventext = Giventext;
    }
    
    public String highlightMatchedString(String Substring) 
    {
        StringBuilder highlightedText = new StringBuilder(Giventext);

        List<Integer> occurrences = findAllOccurrences(Substring);

        for (int i = occurrences.size() - 1; i >= 0; i--) 
        {
            int start = occurrences.get(i);
            int end = start + Substring.length();

            highlightedText.insert(end, "</b>");
            highlightedText.insert(start, "<b>");
        }

        return highlightedText.toString();
    }
    
    public List<Integer> findAllOccurrences(String Substring) 
    {
        List<Integer> occurrences = new ArrayList<>();
        Pattern pattern = Pattern.compile(Substring);
        Matcher matcher = pattern.matcher(Giventext);

        while(matcher.find()) 
        {
            occurrences.add(matcher.start());
        }

        return occurrences;
    }

    public static void main(String[] args) {
    	
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the Text");
        String text = sc.nextLine();
        StringSearchEngine searchEngine = new StringSearchEngine(text);
        System.out.println("Enter the substring you want to search in the text");
        String substringToSearch = sc.nextLine();
        List<Integer> occurrences = searchEngine.findAllOccurrences(substringToSearch);

        System.out.println("Occurrences of " + substringToSearch + " in the text is : " + occurrences);

        String highlightedText = searchEngine.highlightMatchedString(substringToSearch);
        System.out.println("The Highligthed text is :\n" + highlightedText);
    }
}
