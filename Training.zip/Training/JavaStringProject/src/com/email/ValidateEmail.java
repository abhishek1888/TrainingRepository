package com.email;

import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidateEmail {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	   System.out.println("Enter the email");
       Scanner sc=new Scanner(System.in);
       String email=sc.nextLine();
       if(Pattern.matches("^[_a-zA-Z0-9-]+@[a-zA-Z]+\\.[a-z]{2,4}$",email))
    	   System.out.println("The email is valid");
       else
    	   System.out.println("The email is not valid");
	}
}
