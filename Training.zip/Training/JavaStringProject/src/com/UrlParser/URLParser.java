package com.UrlParser;

import java.util.HashMap;
import java.util.Map;

public class URLParser {
    private String url;

    public URLParser(String url) {
        this.url = url;
    }

    public String getProtocol() {
        return url.split(":")[0];
    }

    public String getHost() {
        String[] parts = url.split("//");
        return parts.length > 1 ? parts[1].split("/")[0] : "";
    }

    public String getPath() {
        String[] parts = url.split("//");
        if (parts.length > 1) {
            String[] remainingParts = parts[1].split("/", 2);
            return remainingParts.length > 1 ? remainingParts[1] : "";
        }
        return "";
    }

    public Map<String, String> getQueryParameters() {
        Map<String, String> queryParams = new HashMap<>();
        String[] parts = url.split("\\?");
        if (parts.length > 1) {
            String queryString = parts[1];
            String[] pairs = queryString.split("&");
            for (String pair : pairs) {
                String[] keyValue = pair.split("=");
                if (keyValue.length == 2) {
                    queryParams.put(keyValue[0], keyValue[1]);
                }
            }
        }
        return queryParams;
    }

    public String toString() {
        return "Protocol: " + getProtocol() + "\nHost: " + getHost() + "\nPath: " + getPath() + "\nQuery Parameters: " + getQueryParameters();
    }

    public static void main(String[] args) {
        String sampleURL = "https://www.linkedin.com/company?param1=hexaware-technologies&param2=about";
        URLParser urlParser = new URLParser(sampleURL);
        System.out.println(urlParser.toString());
        System.out.println("Protocol: " + urlParser.getProtocol());
        System.out.println("Host: " + urlParser.getHost());
        System.out.println("Path: " + urlParser.getPath());
        System.out.println("Query Parameters: " + urlParser.getQueryParameters());
    }
}

class URLBuilder {
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParameters;
	private String queryParams;

    public URLBuilder() {
        this.queryParameters = new HashMap<>();
    }

    public URLBuilder setProtocol(String protocol) {
        this.protocol = protocol;
        return this;
    }

    public URLBuilder setHost(String host) {
        this.host = host;
        return this;
    }

    public URLBuilder setPath(String path) {
        this.path = path;
        return this;
    }

    public URLBuilder addQueryParameter(String key, String value) {
        this.queryParameters.put(key, value);
        return this;
    }

    public String build() {
        StringBuilder url = new StringBuilder();
        if (protocol != null) {
            url.append(protocol).append("://");
        }
        if (host != null) {
            url.append(host);
        }
        if (path != null) {
            url.append("/").append(path);
        }
        if (!queryParameters.isEmpty()) {
            url.append("?");
            for (Map.Entry<String, String> entry : queryParameters.entrySet()) {
                url.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
            url.deleteCharAt(url.length() - 1); // Remove the trailing "&"
        }
        return url.toString();
    }

    public static void main(String[] args) {
        URLBuilder urlBuilder = new URLBuilder();
        String finalURL = urlBuilder.setProtocol("https")
                .setHost("www.linkedin.com")
                .setPath("company")
                .addQueryParameter("param1", "Capgemini")
                .addQueryParameter("param2", "about")
                .build();

        System.out.println("Built URL: " + finalURL);
        System.out.println("Separate Components:");
        System.out.println("Protocol: " + urlBuilder.protocol);
        System.out.println("Host: " + urlBuilder.host);
        System.out.println("Path: " + urlBuilder.path);
        System.out.println("Query Parameters: ");
        for (Map.Entry<String, String> entry : urlBuilder.queryParameters.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
