package com.StringBuilder;

public class NewStringBuilder {
	private char[] Strvalue;
    private int size;
    private static final int DEFAULT_CAPACITY = 30;

    public NewStringBuilder() 
    {
    	size = 0;
        Strvalue = new char[DEFAULT_CAPACITY]; 
    }

    public void append(String str) 
    {
        EnsureStrCapacity(size + str.length());
        str.getChars(0, str.length(), Strvalue, size);
        size += str.length();
    }

    public void insert(int index, String str) 
    {
        if (index < 0 || index > size) 
        {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }

        EnsureStrCapacity(size + str.length());
        System.arraycopy(Strvalue, index, Strvalue, index + str.length(), size - index);
        str.getChars(0, str.length(), Strvalue, index);
        size += str.length();
    }

    public void delete(int start, int end) 
    {
        if (start < 0 || end > size || start > end) {
            throw new IndexOutOfBoundsException("Invalid start or end index");
        }

        System.arraycopy(Strvalue, end, Strvalue, start, size - end);
        size -= (end - start);
    }

    @Override
    public String toString() 
    {
        return new String(Strvalue, 0, size);
    }

    private void EnsureStrCapacity(int minCapacity) 
    {
        if (minCapacity > Strvalue.length) 
        {
            int newCapacity = Math.max(minCapacity, Strvalue.length * 2);
            char[] NewStrval = new char[newCapacity];
            System.arraycopy(Strvalue, 0, NewStrval, 0, size);
            Strvalue = NewStrval;
        }
    }

    public static void main(String[] args) 
    {
        NewStringBuilder myStringBuilder = new NewStringBuilder();

        myStringBuilder.append("How are");
        System.out.println("After performing append function the string is : " + myStringBuilder);

        myStringBuilder.insert(4, "beautiful ");
        System.out.println("After performing insert function the string is: " + myStringBuilder);

        myStringBuilder.delete(0, 4);
        System.out.println("After performing delete function the string is: " + myStringBuilder);
    }
}
